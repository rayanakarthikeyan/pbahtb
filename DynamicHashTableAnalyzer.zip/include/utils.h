#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int* generate_random_keys(int n, int max_val);
void print_array(int arr[], int n);

#endif
